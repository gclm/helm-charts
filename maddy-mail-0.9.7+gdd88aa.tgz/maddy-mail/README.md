# Maddy Mail Server

可组合的多合一邮件服务器

- 上游: 1Panel-dev/appstore `apps/maddy-mail` @ `e8549e6df6ca`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install maddy-mail gclm/maddy-mail
```
