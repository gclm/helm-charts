# ComfyUI

具备可视化节点图界面的强大模块化 AI 创作引擎

- 上游: 1Panel-dev/appstore `apps/comfyui` @ `8c586bba9f17`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install comfyui gclm/comfyui
```
