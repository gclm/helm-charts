# Material for MkDocs

Markdown 文件托管平台

- 上游: 1Panel-dev/appstore `apps/mkdocs-material` @ `b1efb5a24f3b`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install mkdocs-material gclm/mkdocs-material
```
