# Lsky-pro

用于在线上传、管理图片的图床程序

- 上游: 1Panel-dev/appstore `apps/lsky-pro` @ `f46185d56db9`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install lsky-pro gclm/lsky-pro
```
