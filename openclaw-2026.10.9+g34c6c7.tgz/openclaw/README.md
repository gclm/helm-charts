# OpenClaw

开源、自托管的个人 AI 助理

- 上游: 1Panel-dev/appstore `apps/openclaw` @ `f97a0a8a2e52`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install openclaw gclm/openclaw
```
