# RabbitMQ

功能丰富的多协议消息传递和流媒体代理

- 上游: 1Panel-dev/appstore `apps/rabbitmq` @ `17bc20d98a2a`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install rabbitmq gclm/rabbitmq
```
