# LangBot

开源的 LLM 原生 IM 机器人开发平台

- 上游: 1Panel-dev/appstore `apps/langbot` @ `f46185d56db9`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install langbot gclm/langbot
```
