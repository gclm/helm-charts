# DVWA

一个用来进行安全脆弱性鉴定的 PHP/MySQL Web 应用平台。

- 上游: 1Panel-dev/appstore `apps/dvwa` @ `e8549e6df6ca`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install dvwa gclm/dvwa
```
