# DeepSeek Harness

DeepSeek 开源智能体开发环境

- 上游: 1Panel-dev/appstore `apps/deepseek-harness` @ `f0b3e6256059`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install deepseek-harness gclm/deepseek-harness
```
