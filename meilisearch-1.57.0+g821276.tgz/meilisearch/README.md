# MeiliSearch

开源、快如闪电且高度相关的搜索引擎

- 上游: 1Panel-dev/appstore `apps/meilisearch` @ `b1efb5a24f3b`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install meilisearch gclm/meilisearch
```
