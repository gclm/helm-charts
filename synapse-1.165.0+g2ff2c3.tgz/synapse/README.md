# Synapse

开源的 Matrix 家庭服务器，自建聊天服务端

- 上游: 1Panel-dev/appstore `apps/synapse` @ `b1efb5a24f3b`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install synapse gclm/synapse
```
