# 思源笔记

隐私优先的个人知识管理系统

- 上游: 1Panel-dev/appstore `apps/siyuan` @ `3b56f010bc5a`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install siyuan gclm/siyuan
```
