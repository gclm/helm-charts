# Palworld Server

幻兽帕鲁服务端

- 上游: 1Panel-dev/appstore `apps/palworld` @ `f46185d56db9`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install palworld gclm/palworld
```
