# Calibre-Web

用于浏览、阅读和下载 Calibre 数据库中存储的电子书的 Web 应用程序

- 上游: 1Panel-dev/appstore `apps/calibre-web` @ `9afa0615a38e`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install calibre-web gclm/calibre-web
```
