# RocketMQ

云原生消息传递和流媒体平台

- 上游: 1Panel-dev/appstore `apps/rocketmq` @ `4a026c7a5152`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install rocketmq gclm/rocketmq
```
