# Ghost

最佳开源博客和电子报平台。

- 上游: 1Panel-dev/appstore `apps/ghost` @ `4c94dad79cf7`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install ghost gclm/ghost
```
