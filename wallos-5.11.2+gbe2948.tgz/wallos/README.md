# Wallos

开源个人订阅跟踪器

- 上游: 1Panel-dev/appstore `apps/wallos` @ `b256fbfd9b69`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install wallos gclm/wallos
```
