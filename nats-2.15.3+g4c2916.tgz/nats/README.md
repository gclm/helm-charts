# NATS

开源、高性能的云原生消息系统

- 上游: 1Panel-dev/appstore `apps/nats` @ `fe7ff6ad1df8`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install nats gclm/nats
```
