# Java

Java 运行环境

- 上游: 1Panel-dev/appstore `apps/java` @ `17bc20d98a2a`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install java gclm/java
```
