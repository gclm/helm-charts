# File Browser

网页文件浏览器

- 上游: 1Panel-dev/appstore `apps/filebrowser` @ `36705fd924e8`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install filebrowser gclm/filebrowser
```
