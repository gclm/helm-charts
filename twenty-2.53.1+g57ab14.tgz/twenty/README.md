# Twenty

由社区驱动的现代化 Salesforce 替代方案

- 上游: 1Panel-dev/appstore `apps/twenty` @ `f97a0a8a2e52`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install twenty gclm/twenty
```
