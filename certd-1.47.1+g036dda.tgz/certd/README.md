# Certd

开源免费的证书管理工具

- 上游: 1Panel-dev/appstore `apps/certd` @ `b256fbfd9b69`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install certd gclm/certd
```
