# Vane

AI 驱动的智能问答引擎

- 上游: 1Panel-dev/appstore `apps/vane` @ `9bd91fd32197`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install vane gclm/vane
```
