# MaxKB

强大易用的企业级智能体平台

- 上游: 1Panel-dev/appstore `apps/maxkb` @ `08ae7d8659cd`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install maxkb gclm/maxkb
```
