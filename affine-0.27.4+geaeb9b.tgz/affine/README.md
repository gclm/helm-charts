# AFFiNE

将文档、白板和数据库完全整合的工作空间

- 上游: 1Panel-dev/appstore `apps/affine` @ `f1cb26b6b292`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install affine gclm/affine
```
