# Docker Registry

Docker 镜像存储库

- 上游: 1Panel-dev/appstore `apps/docker-registry` @ `f46185d56db9`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install docker-registry gclm/docker-registry
```
