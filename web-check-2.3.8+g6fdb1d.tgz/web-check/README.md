# Web-Check

用于分析任何网站的多合一 OSINT 工具

- 上游: 1Panel-dev/appstore `apps/web-check` @ `36705fd924e8`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install web-check gclm/web-check
```
