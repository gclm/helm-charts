# Glance

一个将所有您的源订阅集中在一个地方的托管仪表板

- 上游: 1Panel-dev/appstore `apps/glance` @ `1625f75547e3`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install glance gclm/glance
```
