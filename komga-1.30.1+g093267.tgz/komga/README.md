# Komga

免费开源的漫画、杂志媒体服务

- 上游: 1Panel-dev/appstore `apps/komga` @ `e8549e6df6ca`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install komga gclm/komga
```
