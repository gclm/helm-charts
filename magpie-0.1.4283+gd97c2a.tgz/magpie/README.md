# magpie

一处管理所有 Agent 的模型与供应商的 AI 网关。

- 上游: 1Panel-dev/appstore `apps/magpie` @ `9afa0615a38e`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install magpie gclm/magpie
```
