# Umami

Google Analytics 的简单、快速、注重隐私的替代方案

- 上游: 1Panel-dev/appstore `apps/umami` @ `33c0c8ed7e17`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install umami gclm/umami
```
