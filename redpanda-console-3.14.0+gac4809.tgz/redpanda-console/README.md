# Redpanda Console

Kafka Web 管理工具

- 上游: 1Panel-dev/appstore `apps/redpanda-console` @ `9afa0615a38e`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install redpanda-console gclm/redpanda-console
```
