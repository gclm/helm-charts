# TrendRadar

多平台热点推送

- 上游: 1Panel-dev/appstore `apps/trendradar` @ `3569a3ec3964`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install trendradar gclm/trendradar
```
