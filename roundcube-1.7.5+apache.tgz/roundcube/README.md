# Roundcube

基于 Web 的多语言 IMAP 邮件客户端

- 上游: 1Panel-dev/appstore `apps/roundcube` @ `fb78ceed0ce2`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install roundcube gclm/roundcube
```
