# Dashy

专为您打造的可自行托管的个人仪表板

- 上游: 1Panel-dev/appstore `apps/dashy` @ `fb78ceed0ce2`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install dashy gclm/dashy
```
