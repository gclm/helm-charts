# SonarQube

开源的代码质量管理平台

- 上游: 1Panel-dev/appstore `apps/sonarqube` @ `79cf43943621`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install sonarqube gclm/sonarqube
```
