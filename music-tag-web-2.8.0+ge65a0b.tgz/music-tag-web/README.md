# Music Tag Web

适用于远程与 NAS 音乐库的 Web 音乐标签编辑器

- 上游: 1Panel-dev/appstore `apps/music-tag-web` @ `33c0c8ed7e17`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install music-tag-web gclm/music-tag-web
```
