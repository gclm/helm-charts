# Beszel

轻量易用的服务器监控

- 上游: 1Panel-dev/appstore `apps/beszel` @ `9afa0615a38e`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install beszel gclm/beszel
```
