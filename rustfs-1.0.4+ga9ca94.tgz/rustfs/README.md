# RustFS

兼容 S3 协议的开源分布式对象存储系统

- 上游: 1Panel-dev/appstore `apps/rustfs` @ `fb78ceed0ce2`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install rustfs gclm/rustfs
```
