# Cloudreve

支持多家云存储的云盘系统

- 上游: 1Panel-dev/appstore `apps/cloudreve` @ `5934f90d31a6`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install cloudreve gclm/cloudreve
```
