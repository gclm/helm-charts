# YesPlayMusic

高颜值的第三方网易云播放器

- 上游: 1Panel-dev/appstore `apps/yesplaymusic` @ `e8549e6df6ca`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install yesplaymusic gclm/yesplaymusic
```
