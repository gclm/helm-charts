# Keycloak

面向现代应用与服务的开源身份和访问管理器

- 上游: 1Panel-dev/appstore `apps/keycloak` @ `3b56f010bc5a`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install keycloak gclm/keycloak
```
