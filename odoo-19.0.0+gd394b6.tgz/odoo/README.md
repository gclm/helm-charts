# Odoo

企业一站式管理专家

- 上游: 1Panel-dev/appstore `apps/odoo` @ `8c586bba9f17`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install odoo gclm/odoo
```
