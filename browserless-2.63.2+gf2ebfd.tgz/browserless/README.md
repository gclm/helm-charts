# Browserless

在 Docker 中部署无头浏览器

- 上游: 1Panel-dev/appstore `apps/browserless` @ `e8549e6df6ca`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install browserless gclm/browserless
```
