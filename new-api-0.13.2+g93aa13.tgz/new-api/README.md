# New API

新一代大模型网关与 AI 资产管理系统

- 上游: 1Panel-dev/appstore `apps/new-api` @ `fe7ff6ad1df8`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install new-api gclm/new-api
```
