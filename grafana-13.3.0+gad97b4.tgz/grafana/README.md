# Grafana

用于监控和可观察的开源平台

- 上游: 1Panel-dev/appstore `apps/grafana` @ `3464e24561af`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install grafana gclm/grafana
```
