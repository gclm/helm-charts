# GSManager

新一代游戏服务器管理平台

- 上游: 1Panel-dev/appstore `apps/gsmanager` @ `b2a47839b52c`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install gsmanager gclm/gsmanager
```
