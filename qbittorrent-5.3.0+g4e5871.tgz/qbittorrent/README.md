# qBittorrent

跨平台的开源 BitTorrent 客户端

- 上游: 1Panel-dev/appstore `apps/qbittorrent` @ `488873b3f4e7`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install qbittorrent gclm/qbittorrent
```
