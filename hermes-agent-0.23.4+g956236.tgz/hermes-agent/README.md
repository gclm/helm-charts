# Hermes Agent

Nous Research 开源的自托管 AI 智能体

- 上游: 1Panel-dev/appstore `apps/hermes-agent` @ `857c8b4ce79d`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install hermes-agent gclm/hermes-agent
```
