# MCSManager

Minecraft 服务器控制面板（前端）

- 上游: 1Panel-dev/appstore `apps/mcsmanager-web` @ `f0b3e6256059`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install mcsmanager-web gclm/mcsmanager-web
```
