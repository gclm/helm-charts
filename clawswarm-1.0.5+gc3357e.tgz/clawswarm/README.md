# ClawSwarm

面向 OpenClaw 的开源群体智能协作编排系统

- 上游: 1Panel-dev/appstore `apps/clawswarm` @ `1625f75547e3`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install clawswarm gclm/clawswarm
```
