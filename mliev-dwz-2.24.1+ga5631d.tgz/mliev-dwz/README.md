# 木雷短网址

高性能的企业级短链接服务平台

- 上游: 1Panel-dev/appstore `apps/mliev-dwz` @ `e8549e6df6ca`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install mliev-dwz gclm/mliev-dwz
```
