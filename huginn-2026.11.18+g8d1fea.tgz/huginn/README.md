# Huginn

一个用于构建代理系统的工具，可以为你在线执行自动化任务

- 上游: 1Panel-dev/appstore `apps/huginn` @ `e8549e6df6ca`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install huginn gclm/huginn
```
