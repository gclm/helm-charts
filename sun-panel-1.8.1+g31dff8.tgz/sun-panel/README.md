# Sun-Panel

一个服务器、NAS 导航面板、首页与浏览器起始页

- 上游: 1Panel-dev/appstore `apps/sun-panel` @ `4a026c7a5152`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install sun-panel gclm/sun-panel
```
