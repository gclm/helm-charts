# Mattermost

开源安全团队协作平台

- 上游: 1Panel-dev/appstore `apps/mattermost` @ `33c0c8ed7e17`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install mattermost gclm/mattermost
```
