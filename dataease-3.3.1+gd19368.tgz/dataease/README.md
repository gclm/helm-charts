# DataEase

人人可用的开源 BI 工具

- 上游: 1Panel-dev/appstore `apps/dataease` @ `f0b3e6256059`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install dataease gclm/dataease
```
