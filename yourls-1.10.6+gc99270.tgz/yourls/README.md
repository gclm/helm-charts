# YOURLS

PHP 驱动的标准自托管 URL 缩短器

- 上游: 1Panel-dev/appstore `apps/yourls` @ `33c0c8ed7e17`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install yourls gclm/yourls
```
