# Zabbix Server

面向 IT 和 OT 的通用开源可观测性解决方案

- 上游: 1Panel-dev/appstore `apps/zabbix-server` @ `5934f90d31a6`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install zabbix-server gclm/zabbix-server
```
