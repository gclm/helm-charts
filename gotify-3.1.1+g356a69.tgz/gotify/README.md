# Gotify

简单的服务器来发送和接收消息

- 上游: 1Panel-dev/appstore `apps/gotify` @ `5934f90d31a6`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install gotify gclm/gotify
```
