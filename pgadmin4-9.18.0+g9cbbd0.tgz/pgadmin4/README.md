# PGAdmin4

PostgreSQL 开源管理工具

- 上游: 1Panel-dev/appstore `apps/pgadmin4` @ `8c586bba9f17`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install pgadmin4 gclm/pgadmin4
```
