# Verdaccio

本地私有 NPM 注册中心

- 上游: 1Panel-dev/appstore `apps/verdaccio` @ `f1cb26b6b292`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install verdaccio gclm/verdaccio
```
