# Twikoo

简洁、安全、免费的静态网站评论系统

- 上游: 1Panel-dev/appstore `apps/twikoo` @ `7ca256fe5cd9`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install twikoo gclm/twikoo
```
