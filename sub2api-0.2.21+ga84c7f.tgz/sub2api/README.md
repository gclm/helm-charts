# Sub2API

AI API 网关平台，支持订阅配额分发与管理

- 上游: 1Panel-dev/appstore `apps/sub2api` @ `9afa0615a38e`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install sub2api gclm/sub2api
```
