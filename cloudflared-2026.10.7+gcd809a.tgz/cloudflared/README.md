# cloudflared

Cloudflare Tunnel 客户端

- 上游: 1Panel-dev/appstore `apps/cloudflared` @ `3569a3ec3964`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install cloudflared gclm/cloudflared
```
