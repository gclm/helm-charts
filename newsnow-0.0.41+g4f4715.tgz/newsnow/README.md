# NewsNow

优雅地阅读实时热门新闻

- 上游: 1Panel-dev/appstore `apps/newsnow` @ `fb78ceed0ce2`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install newsnow gclm/newsnow
```
