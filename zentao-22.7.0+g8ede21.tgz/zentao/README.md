# 禅道

敏捷（scrum）项目管理系统/工具，永久免费升级

- 上游: 1Panel-dev/appstore `apps/zentao` @ `33c0c8ed7e17`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install zentao gclm/zentao
```
