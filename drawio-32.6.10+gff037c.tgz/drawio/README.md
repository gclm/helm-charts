# Draw.io

用于一般图表绘制的 JavaScript 客户端编辑器

- 上游: 1Panel-dev/appstore `apps/drawio` @ `fe7ff6ad1df8`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install drawio gclm/drawio
```
