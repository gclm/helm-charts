# .NET

.NET 运行环境

- 上游: 1Panel-dev/appstore `apps/dotnet` @ `9afa0615a38e`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install dotnet gclm/dotnet
```
