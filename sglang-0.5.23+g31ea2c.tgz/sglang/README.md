# SGLang

开源的大语言模型、视觉语言模型与扩散模型推理框架

- 上游: 1Panel-dev/appstore `apps/sglang` @ `33c0c8ed7e17`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install sglang gclm/sglang
```
