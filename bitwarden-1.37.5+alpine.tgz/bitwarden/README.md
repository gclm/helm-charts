# Bitwarden

开源的密码管理服务

- 上游: 1Panel-dev/appstore `apps/bitwarden` @ `b1efb5a24f3b`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install bitwarden gclm/bitwarden
```
