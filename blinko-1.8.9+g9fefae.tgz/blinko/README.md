# Blinko

开源自托管的个人轻量笔记/闪念胶囊工具

- 上游: 1Panel-dev/appstore `apps/blinko` @ `e8549e6df6ca`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install blinko gclm/blinko
```
