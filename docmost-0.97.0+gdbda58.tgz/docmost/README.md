# Docmost

开源协作 wiki 与文档软件

- 上游: 1Panel-dev/appstore `apps/docmost` @ `a0d47734eab0`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install docmost gclm/docmost
```
