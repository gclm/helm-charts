# JSON Hero

开源、美观的 Web JSON 浏览器

- 上游: 1Panel-dev/appstore `apps/jsonhero` @ `b256fbfd9b69`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install jsonhero gclm/jsonhero
```
