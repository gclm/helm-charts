# Focalboard

Trello、Notion 和 Asana 的开源自托管替代方案

- 上游: 1Panel-dev/appstore `apps/focalboard` @ `b1efb5a24f3b`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install focalboard gclm/focalboard
```
