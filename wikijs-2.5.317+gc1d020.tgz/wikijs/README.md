# Wiki.js

基于 Node.js 构建的现代而强大的 Wiki 应用程序

- 上游: 1Panel-dev/appstore `apps/wikijs` @ `f97a0a8a2e52`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install wikijs gclm/wikijs
```
