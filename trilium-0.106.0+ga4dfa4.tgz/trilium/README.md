# Trilium

使用 Trilium Notes 建立个人知识库

- 上游: 1Panel-dev/appstore `apps/trilium` @ `08ae7d8659cd`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install trilium gclm/trilium
```
