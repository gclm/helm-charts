# FreshRSS

自托管的 RSS 和 Atom 源聚合器

- 上游: 1Panel-dev/appstore `apps/freshrss` @ `33c0c8ed7e17`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install freshrss gclm/freshrss
```
