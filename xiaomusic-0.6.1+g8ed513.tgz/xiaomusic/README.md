# XiaoMusic

无限听歌，解放小爱音箱

- 上游: 1Panel-dev/appstore `apps/xiaomusic` @ `9bd91fd32197`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install xiaomusic gclm/xiaomusic
```
