# Certimate

一个安全、简便的 SSL 证书管理解决方案

- 上游: 1Panel-dev/appstore `apps/certimate` @ `60db3c829021`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install certimate gclm/certimate
```
