# LobeChat

开源、现代设计的 ChatGPT/LLMs UI/框架

- 上游: 1Panel-dev/appstore `apps/lobe-chat` @ `f0b3e6256059`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install lobe-chat gclm/lobe-chat
```
