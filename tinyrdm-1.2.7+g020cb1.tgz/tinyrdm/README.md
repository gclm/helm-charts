# Tiny RDM

一个现代化轻量级的跨平台 Redis 客户端

- 上游: 1Panel-dev/appstore `apps/tinyrdm` @ `9b9032d60dfc`
- 分类: unknown
- 转换产物：不手改（见仓库 README 治理规则）；定制走 `overlay/apps/{app}/`

## 安装

```bash
helm install tinyrdm gclm/tinyrdm
```
